const display = document.getElementById("display");
const buttons = document.querySelectorAll("button");

let currentInput = "";

buttons.forEach(button => {
    button.addEventListener("click", () => {
        const value = button.textContent;

        if (value === "C") {
            currentInput = "";
            display.value = "";
        } else if (value === "=") {
            if (currentInput === "") return;

            try {
                const expression = currentInput
                    .replace(/×/g, "*")
                    .replace(/÷/g, "/")
                    .replace(/−/g, "-");

                // Only digits, operators, brackets and decimal points allowed
                if (!/^[0-9+\-*/().\s]+$/.test(expression)) {
                    throw new Error("Invalid expression");
                }

                const result = Function(
                    '"use strict"; return (' + expression + ')'
                )();

                if (!Number.isFinite(result)) {
                    throw new Error("Math error");
                }

                // Trim floating point noise (e.g. 0.1 + 0.2)
                display.value = parseFloat(result.toPrecision(12));
                currentInput = String(display.value);
            } catch {
                display.value = "Error";
                currentInput = "";
            }
        } else {
            // Clear a previous "Error" before typing again
            if (display.value === "Error") {
                currentInput = "";
            }
            currentInput += value;
            display.value = currentInput;
        }
    });
});
