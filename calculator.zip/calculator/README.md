# Calculator

Simple responsive web calculator built with HTML, CSS and vanilla JavaScript. Supports addition, subtraction, multiplication, division, decimals and brackets, with clear and error handling. A beginner-friendly project with a clean dark-themed grid layout.

## Features
- Basic operations: +, −, ×, ÷
- Decimal numbers and brackets
- Clear (C) button
- Error handling for invalid input and division by zero
- Floating-point cleanup (0.1 + 0.2 shows 0.3)

## Tech Stack
HTML5, CSS3 (Grid), JavaScript (ES6)

## Run Locally
Clone the repo and open `index.html` in your browser. No build step needed.

## Files
- `index.html` - layout
- `style2.css` - styling
- `script2.js` - calculator logic

## License
MIT
